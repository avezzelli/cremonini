<?php
echo $_SERVER["DOCUMENT_ROOT"];
echo '<br>';
echo $_SERVER['HTTP_HOST'];
?>